import { createApp } from './vendor/vue.esm-browser.js';

createApp({
    data() {
      return {
        firstNum: 0,
        secondNum: 0,
        action: '',
      }
    },

    computed: {
        result(){
            if(this.action === 'sum'){
                return this.firstNum + this.secondNum;
            }else if(this.action === 'subtract'){
                return  this.firstNum - this.secondNum;
            }else if(this.action === 'multiply'){
                return  this.firstNum * this.secondNum;
            }else if(this.action === 'divide'){
                return this.firstNum / this.secondNum;
            }
        }}
    }).mount('#app')
